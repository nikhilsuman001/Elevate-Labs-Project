#!/usr/bin/env python3
"""
stego.py - Simple LSB steganography for PNG images (lossless)
Usage:
  Encode: python stego.py encode input.png "secret message" output.png
  Decode: python stego.py decode input.png
"""
import sys
from PIL import Image

def _int_to_bits(n, bits=32):
    return [(n >> i) & 1 for i in range(bits-1, -1, -1)]

def _bytes_to_bits(b):
    bits = []
    for byte in b:
        bits.extend(_int_to_bits(byte, 8))
    return bits

def _bits_to_bytes(bits):
    out = bytearray()
    for i in range(0, len(bits), 8):
        byte = 0
        for bit in bits[i:i+8]:
            byte = (byte << 1) | bit
        out.append(byte)
    return bytes(out)

def encode(input_path, message, output_path):
    img = Image.open(input_path)
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGBA")
    pixels = list(img.getdata())
    data = message.encode('utf-8')
    length = len(data)
    bits = _int_to_bits(length, 32) + _bytes_to_bits(data)
    capacity = len(pixels) * 3
    if len(bits) > capacity:
        raise ValueError("Message too large for image capacity.")
    new_pixels = []
    bit_idx = 0
    for px in pixels:
        r, g, b = px[0], px[1], px[2]
        if bit_idx < len(bits): r = (r & ~1) | bits[bit_idx]; bit_idx += 1
        if bit_idx < len(bits): g = (g & ~1) | bits[bit_idx]; bit_idx += 1
        if bit_idx < len(bits): b = (b & ~1) | bits[bit_idx]; bit_idx += 1
        new_pixels.append((r, g, b) + ((px[3],) if len(px) == 4 else ()))
    out = Image.new(img.mode, img.size)
    out.putdata(new_pixels)
    out.save(output_path, "PNG")
    print(f"Encoded message ({length} bytes) into {output_path}")

def decode(input_path):
    img = Image.open(input_path)
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGBA")
    pixels = list(img.getdata())
    bits = []
    for px in pixels:
        bits.extend([px[0] & 1, px[1] & 1, px[2] & 1])
    length_bits = bits[:32]
    length = 0
    for b in length_bits:
        length = (length << 1) | b
    message_bits = bits[32:32 + length * 8]
    message = _bits_to_bytes(message_bits).decode('utf-8', errors='replace')
    print(f"Decoded message ({length} bytes): {message}")

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    cmd = sys.argv[1].lower()
    if cmd == "encode":
        if len(sys.argv) != 5:
            print("Usage: python stego.py encode input.png \"secret\" output.png")
            sys.exit(1)
        encode(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "decode":
        if len(sys.argv) != 3:
            print("Usage: python stego.py decode input.png")
            sys.exit(1)
        decode(sys.argv[2])
    else:
        print("Unknown command.")
        sys.exit(1)

if __name__ == "__main__":
    main()
